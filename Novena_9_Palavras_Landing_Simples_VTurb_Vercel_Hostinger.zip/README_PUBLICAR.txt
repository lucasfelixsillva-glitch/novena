LANDING PAGE SIMPLES — NOVENA DAS 9 PALAVRAS

1. A pagina inicial esta em index.html. VSL VTurb ja integrada com o ID vid-6af31db5f821f994a64099cd.
2. NAO existe botao de compra criado no HTML. O botao/checkout deve ser configurado no painel da VTurb, como parte do proprio player/VSL.
3. Para que o CTA apareca aos ~34 minutos (ou no momento escolhido), configure o botao dentro da VTurb. Este site nao adiciona scripts de tempo, pitch ou botoes externos.
4. Vercel: suba estes arquivos no repositorio GitHub, importe na Vercel como projeto estatico, sem framework e sem build command.
5. Hostinger: envie o conteudo desta pasta para public_html (o index.html deve ficar diretamente dentro dela).
6. Antes da publicacao comercial, complete paginas privacidade.html e termos.html com dados reais do vendedor.
7. Teste a VSL e o CTA no dominio publicado: os scripts remotos da VTurb podem nao carregar em visualizacoes locais.
8. A imagem da capa e uma previa do produto. O PDF pago nao esta dentro dos arquivos publicos.
